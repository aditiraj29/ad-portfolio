# Put the portfolio live — start here

```
aditi-portfolio-FINAL/
├─ site/                ← THE WEBSITE. Upload the contents of this folder (steps below)
├─ DEPLOY.md            ← this file
├─ LINKEDIN.md          ← post copy + how to get a proper link preview on phone and laptop
└─ source-and-tools/    ← NOT for upload: dev notes, portrait + share-image tools
```

Everything the site needs is inside `site/` (14 files, under 500 KB). The only thing it loads from the internet is
the fonts (Google Fonts), so it needs a connection the first time it opens — same as any website.

## Before you publish (2 minutes)

- [ ] **Spyne's OK.** The lead story (Video Outreach in Vini AI) and the "Contracting TAT −52%" figure (labelled
      self-reported) are public once this is live. Get the OK first.
- [ ] **Phone number.** The résumé download is your first résumé, `AD_resume.pdf`, and it contains your phone number.
      Anyone can download it, including scrapers. To remove it: put a copy of the résumé without the number at
      `site/assets/Aditi_Raj_Resume.pdf` (keep that exact file name) before uploading.

## Option A — GitHub Pages (recommended). Result: https://aditiraj29.github.io

Do this on the laptop where you're signed in to your personal GitHub (aditiraj29).

1. Unzip `aditi-portfolio-FINAL.zip` from Google Drive.
2. Go to https://github.com/new → Repository name: **`aditiraj29.github.io`** (exactly) → **Public** → Create repository.
3. On the new empty repo, click **"uploading an existing file"**. Open the `site` folder, select **everything inside it**
   (`index.html`, `css`, `js`, `vendor`, `assets`; Cmd/Ctrl + A) and drag it onto the GitHub page.
   Wait until every file has finished uploading → **Commit changes**.
   `index.html` must sit at the top level of the repo, not inside another folder.
4. Repo → **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*, Branch = **main**, folder =
   **/ (root)** → Save.
5. Wait 1–2 minutes, refresh the Pages screen: it shows *"Your site is live at https://aditiraj29.github.io/"*.
6. Open the link on your laptop **and** on your phone. Then follow `LINKEDIN.md`.

## Option B — Netlify Drop (no GitHub)

1. Open https://app.netlify.com/drop, drag the **`site`** folder onto it, and sign up with an email to keep the site.
2. Site configuration → Change site name → e.g. `aditi-raj` → your link is `https://aditi-raj.netlify.app`.
3. Do the "different address" step below, then drag the `site` folder in again.

## If your address is not https://aditiraj29.github.io

Three lines near the top of `site/index.html` tell LinkedIn what to show when the link is shared. Search the file for
`aditiraj29.github.io` and replace it with your address in these three places: `rel="canonical"`, `og:url`,
`og:image` (e.g. `https://aditi-raj.netlify.app/assets/og.png`). Upload `index.html` again.

## Updating later

Edit the files, then upload the changed ones again (GitHub: repo → Add file → Upload files; it replaces same-named
files). LinkedIn caches link previews, so re-check with the Post Inspector (see `LINKEDIN.md`).
