import Foundation
import Vision
import CoreImage
import AppKit

// usage: mask <input image> <output mask png> [x y]
//   no point : every person in the photo (VNGeneratePersonSegmentationRequest)
//   x y      : only the foreground subject that covers that pixel (top-left origin, source-image pixels),
//              e.g. her face in a photo with other people in the background (VNGenerateForegroundInstanceMaskRequest)
let args = CommandLine.arguments
guard args.count == 3 || args.count == 5 else { print("usage: mask in out [x y]"); exit(1) }
let inURL = URL(fileURLWithPath: args[1])
let outURL = URL(fileURLWithPath: args[2])

guard let ci = CIImage(contentsOf: inURL) else { print("cannot read image"); exit(2) }
let handler = VNImageRequestHandler(ciImage: ci, options: [:])
var maskBuf: CVPixelBuffer

if args.count == 5 {
    guard let px = Double(args[3]), let py = Double(args[4]) else { print("x y must be numbers"); exit(1) }
    let req = VNGenerateForegroundInstanceMaskRequest()
    do { try handler.perform([req]) } catch { print("vision failed: \(error)"); exit(3) }
    guard let obs = req.results?.first else { print("no foreground instances"); exit(4) }

    // which instance sits under the point?
    let labels = obs.instanceMask
    CVPixelBufferLockBaseAddress(labels, .readOnly)
    let bw = CVPixelBufferGetWidth(labels), bh = CVPixelBufferGetHeight(labels)
    let stride = CVPixelBufferGetBytesPerRow(labels)
    let base = CVPixelBufferGetBaseAddress(labels)!.assumingMemoryBound(to: UInt8.self)
    let lx = min(bw - 1, max(0, Int(px / ci.extent.width * Double(bw))))
    let ly = min(bh - 1, max(0, Int(py / ci.extent.height * Double(bh))))
    let label = Int(base[ly * stride + lx])
    CVPixelBufferUnlockBaseAddress(labels, .readOnly)
    print("instances: \(Array(obs.allInstances)), label at point: \(label)")
    let pick: IndexSet = label == 0 ? obs.allInstances : IndexSet(integer: label)
    do { maskBuf = try obs.generateScaledMaskForImage(forInstances: pick, from: handler) }
    catch { print("mask failed: \(error)"); exit(4) }
} else {
    let req = VNGeneratePersonSegmentationRequest()
    req.qualityLevel = .accurate
    req.outputPixelFormat = kCVPixelFormatType_OneComponent8
    do { try handler.perform([req]) } catch { print("vision failed: \(error)"); exit(3) }
    guard let buf = req.results?.first?.pixelBuffer else { print("no mask"); exit(4) }
    maskBuf = buf
}

// scale the mask to the source image size
var mask = CIImage(cvPixelBuffer: maskBuf)
let sx = ci.extent.width / mask.extent.width
let sy = ci.extent.height / mask.extent.height
mask = mask.transformed(by: CGAffineTransform(scaleX: sx, y: sy))
let ctx = CIContext()
guard let cg = ctx.createCGImage(mask, from: ci.extent) else { print("cg failed"); exit(5) }
let rep = NSBitmapImageRep(cgImage: cg)
guard let png = rep.representation(using: .png, properties: [:]) else { print("png failed"); exit(6) }
try png.write(to: outURL)
print("mask written \(Int(ci.extent.width))x\(Int(ci.extent.height))")
