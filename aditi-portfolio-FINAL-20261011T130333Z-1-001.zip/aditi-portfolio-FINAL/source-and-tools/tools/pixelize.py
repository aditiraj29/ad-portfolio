"""
Bake a pixel-art portrait from a photo + person mask.
Only the baked grid (palette indices) is written into the site, never the photo.
usage: python3 pixelize.py src.jpg mask.png[,mask2.png] out_prefix [cols rows [portrait-data.js]] [options]
  mask.png[,mask2.png]  one or more cut-out masks (tools/mask.swift); several are AND-ed together, e.g. the
                        "everyone" mask plus the "just her" instance mask removes the menu card and fork holder
  --crop=x0,y0,cw       crop box in source pixels (left, top, width); the height follows the grid's aspect
  --ramp=#a,#b,#c,...   colours, dark -> light, that the photo's tones are dithered onto
  --dither=0.9          dither strength for the ramp (0 = flat bands, 1 = busy)
  --tone-rows=0.6       set the tone range from only the top fraction of the grid (the face), so a bright
                        shirt doesn't flatten it; default 1.0 = the whole subject
  --photo               keep the photo's natural colours (median-cut palette) instead of a ramp
Default: the portrait is painted in the site's own colours by ordered-dithering the photo's tones onto THEME_RAMP.
Current portrait: pixelize.py photo.jpg both_masks.png /tmp/portrait 72 80 js/portrait-data.js --crop=285,378,430 --dither=0.85 --tone-rows=0.55
Check out_prefix_preview.png, then adjust the crop for a new photo.
"""
import sys, json
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter

opts = [a for a in sys.argv[1:] if a.startswith('--')]
argv = [sys.argv[0]] + [a for a in sys.argv[1:] if not a.startswith('--')]
PHOTO = '--photo' in opts
def opt(name, default=None):
    for o in opts:
        if o.startswith('--' + name + '='):
            return o.split('=', 1)[1]
    return default
src, maskp, out = argv[1], argv[2], argv[3]
COLS = int(argv[4]) if len(argv) > 4 else 72
ROWS = int(argv[5]) if len(argv) > 5 else 80
NCOL = 16
# site theme, dark -> light: --ink, a warm brown, --signal darkened, a newsprint tint, --bg (css/style.css). Kept calm on purpose.
THEME_RAMP = ['#15130f', '#4d3b33', '#a8412b', '#e8d9c0', '#f4efe3']
RAMP = (opt('ramp') or ','.join(THEME_RAMP)).split(',')
DITHER = float(opt('dither', '0.9'))
TONE_ROWS = float(opt('tone-rows', '1.0'))

img = Image.open(src).convert('RGB')
mask = None
for mp in maskp.split(','):
    mm = np.asarray(Image.open(mp).convert('L')).astype(np.uint8)
    assert mm.shape[::-1] == img.size, (mp, mm.shape, img.size)
    mask = mm if mask is None else np.minimum(mask, mm)
mask = Image.fromarray(mask)

# crop: head + shoulders, matching the grid's aspect
W, H = img.size
cw, x0, y0 = 1040, max(0, int(W / 2 - 1040 / 2 - 20)), 110   # defaults tuned for the first stand-in photo
if opt('crop'):
    x0, y0, cw = [int(v) for v in opt('crop').split(',')]
ch = int(cw * ROWS / COLS)
box = (x0, y0, min(W, x0 + cw), min(H, y0 + ch))
img, mask = img.crop(box), mask.crop(box)
# pad if the crop ran off the bottom
if img.size[1] < ch:
    pad = Image.new('RGB', (img.size[0], ch), (0, 0, 0)); pad.paste(img, (0, 0)); img = pad
    mpad = Image.new('L', (mask.size[0], ch), 0); mpad.paste(mask, (0, 0)); mask = mpad

# a touch of punch so features survive the downscale
img = ImageEnhance.Contrast(img).enhance(1.18)
img = ImageEnhance.Color(img).enhance(1.08)
img = img.filter(ImageFilter.UnsharpMask(radius=6, percent=90, threshold=2))

small = img.resize((COLS, ROWS), Image.BOX)
msmall = mask.resize((COLS, ROWS), Image.BOX)
a = np.asarray(small).astype(np.float32)
m = (np.asarray(msmall).astype(np.float32) / 255.0) > 0.5   # crisp, binary cut-out

# ordered (Bayer 4x4) dither matrix
bayer = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], dtype=np.float32) / 16.0 - 0.5
idx = np.zeros((ROWS, COLS), dtype=np.int32)

if PHOTO:
    # natural colours: median-cut palette from the subject pixels only, dithered to nearest colour
    subj = a[m]
    flat = a.copy()
    flat[~m] = subj.mean(axis=0)
    pal_img = Image.fromarray(flat.astype(np.uint8)).quantize(colors=NCOL, method=Image.MEDIANCUT, dither=Image.NONE)
    pal = np.array(pal_img.getpalette()[:NCOL * 3], dtype=np.float32).reshape(-1, 3)
    pal = pal[np.argsort(pal @ np.array([0.299, 0.587, 0.114]))]    # dark -> light, so the indices are tidy
    spread = 16.0
    for y in range(ROWS):
        for x in range(COLS):
            v = a[y, x] + bayer[y % 4, x % 4] * spread
            idx[y, x] = int(((pal - v) ** 2).sum(axis=1).argmin())
else:
    # theme colours: stretch the subject's tones over the ramp, then dither between neighbouring ramp colours
    pal = np.array([[int(h[i:i + 2], 16) for i in (1, 3, 5)] for h in RAMP], dtype=np.float32)
    K = len(pal)
    lum = a @ np.array([0.299, 0.587, 0.114], dtype=np.float32)
    top = m & (np.arange(ROWS)[:, None] < ROWS * TONE_ROWS)
    lo, hi = np.percentile(lum[top], [3, 97])
    t = np.clip((lum - lo) / (hi - lo), 0, 1)
    for y in range(ROWS):
        for x in range(COLS):
            idx[y, x] = int(np.clip(np.floor(t[y, x] * (K - 1) + bayer[y % 4, x % 4] * DITHER + 0.5), 0, K - 1))

DIG = '0123456789abcdefghij'
rows = []
for y in range(ROWS):
    rows.append(''.join(DIG[idx[y, x]] if m[y, x] else '-' for x in range(COLS)))
palette = ['#%02x%02x%02x' % tuple(int(round(c)) for c in p) for p in pal]

data = {'w': COLS, 'h': ROWS, 'pal': palette, 'rows': rows}
json.dump(data, open(out + '.json', 'w'))
if len(argv) > 6:   # write the site's data file directly
    js = ("/* Pixel-art portrait, baked from a photo (palette + grid indices only - the photo itself is not part of the site).\n"
          "   Re-bake with tools/pixelize.py. '-' = transparent. */\nwindow.PORTRAIT = " + json.dumps(data, separators=(',', ':')) + ";\n")
    open(argv[6], 'w').write(js)

# preview: 8× nearest-neighbour on paper, so the result can be eyeballed
S = 8
prev = Image.new('RGB', (COLS * S, ROWS * S), (244, 239, 227))
px = prev.load()
for y in range(ROWS):
    for x in range(COLS):
        if m[y, x]:
            c = tuple(int(v) for v in pal[idx[y, x]])
            for dy in range(S):
                for dx in range(S):
                    px[x * S + dx, y * S + dy] = c
prev.save(out + '_preview.png')
print('palette', palette)
print('cells', COLS, 'x', ROWS, ' subject cells', int(m.sum()), 'of', COLS * ROWS)
