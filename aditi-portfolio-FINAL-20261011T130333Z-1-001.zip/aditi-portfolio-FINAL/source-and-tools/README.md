# Aditi Raj — portfolio · "Signal Edition"

A newspaper front page, printed in pixels. Light theme only.
One idea runs through it: **noise → signal → product**. A pixel field draws itself inside a framed window on
each page and morphs as you scroll.

> *Turning customer noise into product decisions.* — sits beside the name in the intro, the masthead, the running
> header and the footer.

## Run it

Double-click `index.html`, or serve the folder:

```bash
python3 -m http.server 5173
# then open http://localhost:5173
```

Add `?skip` to the URL to skip the preloader (it plays once per browser session anyway).

## Deploy

Static site, no build step. Drag the folder into Netlify Drop, or use `vercel` / GitHub Pages.
Fonts load from Google Fonts; the animation libraries are vendored in `vendor/`.

## The pages

| Page | What it is |
|---|---|
| Intro | The noise assembles **ADITI RAJ** in pixel blocks, types the motto under it, then bursts into the front page |
| Front page | Masthead (letters thicken once on landing, then hold still), motto with marker highlight, metrics ticker, a dateline with your role and city, lead story on the shipped **Video Outreach** feature in Vini AI (twelve sales and service campaigns), and a pixel-art portrait in the site's newsprint colours that resolves out of colour noise, with the pixel wave flowing behind it |
| 2 · Profile | The three skill clusters beside their pixel-field window |
| 3 · Feature | Spyne, as five scroll-driven steps beside a pixel-field window that settles from scattered noise into an ordered grid as the steps advance, with a panel per step; Streamline shows the contracting-TAT result as one small, labelled chip |
| 4 · Features | Three playable demos: Nexpilot agent run, object-detection sketch, live SHA-256 (Evidentia) |
| 5 · Classifieds | Every skill as a pixel sprite — click one to light up the roles/projects it came from; Honours as "unlocked" cards; Education |
| 6 · Letters | Click-to-copy email, the pixel @ |

## Where things live

| File | What it does |
|---|---|
| `index.html` | All the copy |
| `css/style.css` | Design tokens at the top (paper, ink, red, blue, green, marker yellow) and the pixel border system |
| `js/field.js` | The pixel field: six shapes laid out inside each page's `.figure__win`, plus the intro |
| `js/pixel.js` | Pixel-grid dissolve wipe, the scroll-track runner, sprites |
| `js/portrait.js` + `js/portrait-data.js` | The pixel portrait (renderer + baked grid). Resolves out of noise once on landing, then holds still. |
| `tools/` | Re-bake the portrait from a different photo (see below) |
| `js/loadout.js` | Skills + the skill → role/project links (edit the `SKILLS` array) |
| `js/demos.js` | The three playable demos |
| `js/main.js` | Smooth scroll, intro, reveals, scroll-driven feature |
| `assets/og.png` | The 1200×630 picture LinkedIn shows when the link is shared (made from `tools/og/og.html`) |

## Link preview (LinkedIn, WhatsApp, etc.)

`index.html` carries Open Graph tags and `assets/og.png`. They point at **https://aditiraj29.github.io/** — if the live
address is different, change `rel="canonical"`, `og:url` and `og:image` (search the file for `aditiraj29.github.io`).
To regenerate the picture (Chrome installed; needs internet for the fonts):

```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --hide-scrollbars \
  --window-size=1200,630 --virtual-time-budget=12000 --screenshot=assets/og.png "file://$PWD/tools/og/og.html"
```

## Swap the portrait

The site ships only a baked pixel grid (`js/portrait-data.js`) — **the photo itself is never part of the site.**
The bake paints the portrait in calm site colours (ink, warm brown, darkened signal red, newsprint — `THEME_RAMP` in
`tools/pixelize.py`); add `--photo` to keep the photo's natural colours instead.
To bake a different photo (macOS; needs Pillow + numpy). If other people are in the shot, give `mask.swift` a point on
your face so it cuts out only you, and pass both masks to `pixelize.py`:

```bash
swiftc tools/mask.swift -o /tmp/mask
/tmp/mask photo.jpg /tmp/all.png                  # everyone in the photo
/tmp/mask photo.jpg /tmp/me.png 500 560           # only the subject at pixel x=500, y=560 (your face)
python3 tools/pixelize.py photo.jpg /tmp/all.png,/tmp/me.png /tmp/portrait 72 80 js/portrait-data.js \
  --crop=285,378,430 --dither=0.85 --tone-rows=0.55     # the settings behind the current portrait
open /tmp/portrait_preview.png                                                # check it first
```

`--crop=left,top,width` frames the head and shoulders — adjust it for a new photo and check the preview first.
If `portrait-data.js` is missing, the pixel wave shows in that window instead.

## Content rules I followed

- Everything comes from your résumés. **Skill → project links use only what the résumés say** (a project's "Tech:"
  line or an explicit bullet); a skill with no stated link lights up nothing rather than guess.
- **−52% contracting TAT** comes from the *product* résumé (`ad_pdt.pdf`), **not** from the résumé the site now offers
  for download (`AD_resume.pdf`). It is kept to a minimum (one ticker figure, plus the Streamline step) and labelled
  "self-reported". The 21+ → 4 days onboarding figure was removed from the site. Get Spyne's OK before publishing.
- The lead story's wording comes from the **"Your follow-ups now come with a personal video"** one-pager (headline: Video Outreach ships in Vini AI — twelve campaigns across sales and service; "Video Outreach" is the name on the one-pager's file). It states
  product facts only (twelve campaigns: nine sales, three service) — no performance claims. Get Spyne's OK to feature it.
- The Nexpilot graph, detection scene and campaign dashboard are **illustrative** and labelled so. Evidentia's
  hashing is real.
- The résumé download (`assets/Aditi_Raj_Resume.pdf`) is your first résumé, `AD_resume.pdf`. Its header includes your phone number, as résumés do; the page itself keeps the number off.

## Notes

- Calm by design: nothing reacts to the cursor (no custom cursor, trail, magnetic buttons, hover scatter or hover
  highlights). Motion happens on landing (intro, name swell, portrait resolve) and with scroll. Skills respond to a click.
- Honors `prefers-reduced-motion`: no smooth scroll, no preloader, no wipes, no ambient drift.
- If you add a CSS `transition` on opacity/transform to something GSAP animates with `gsap.from()`, use
  `gsap.fromTo()` instead — otherwise GSAP can read a mid-transition value and animate from 0 to 0.
- The previous design (dark/paper "pixel edition") is kept in `../aditi-portfolio-pixel-v2`.
