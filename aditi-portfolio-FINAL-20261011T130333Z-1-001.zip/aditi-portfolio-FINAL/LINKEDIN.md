# Posting it on LinkedIn — so it looks right on phone and laptop

The link preview card (picture, title, line of text) is built from the tags already in `site/index.html` and the image
`site/assets/og.png` (1200 × 630). Once the site is live, the same link opens the same site on laptop and phone.

## Order that works

1. **Publish the site first** (see `DEPLOY.md`) and open the link on your phone and laptop.
2. **Warm the preview.** Open https://www.linkedin.com/post-inspector/ → paste your link → *Inspect*.
   You should see the title "Aditi Raj — Turning customer noise into product decisions" and the pixel-portrait image.
   If it shows something old or blank, click *Inspect* again.
3. **Write the post** (copy below). Paste the link at the end; wait for the card to appear, then you can delete the
   raw link text if you like (the card stays) — or leave it, both work.
4. **Add it to your profile** so people who visit you can find it:
   - Profile → *Contact info* (pencil) → *Website* → add the link, type "Portfolio".
   - Profile → *Featured* (+) → *Add a link* → paste the link.
5. **Check it as a reader.** From your phone, open your post in the LinkedIn app and tap the card. If the animation
   feels slow in LinkedIn's built-in browser, tap **⋯ → Open in browser** (Safari/Chrome); say so in a comment so
   viewers know.
6. **First comment** (optional, helps the post): "Built from scratch with plain HTML, CSS and JavaScript. Tell me what
   you'd improve."

## Post copy

> I built my portfolio as a newspaper front page, printed in pixels.
>
> The idea comes from how I work as a Product Management Intern at Spyne: turning customer noise into product
> decisions. So the site starts as raw noise and resolves into signal: my name, my portrait, then the work.
>
> Scroll and you'll find:
> → The five steps I follow on Vini AI, from Discover to Measure
> → Interactive demos of three projects I've built, right in the browser
> → My skills, with a tap-to-see "where I used it" view
>
> No template: plain HTML, CSS and JavaScript, built from scratch. It works on both phone and laptop.
>
> I'm open to opportunities in product, partnerships and AI-driven initiatives. If you're building AI products and
> want someone who starts from the customer's problem, I'd love to talk.
>
> See it here: https://aditiraj29.github.io
>
> #ProductManagement #Portfolio #AI #PMIntern #OpenToWork

## Shorter version

> New portfolio, built from scratch: a newspaper front page printed in pixels. It starts as noise and resolves into
> signal, which is how I try to work as a Product Management Intern at Spyne. Three interactive projects, my skills and
> how I approach product work — on phone and laptop.
> https://aditiraj29.github.io
> #ProductManagement #Portfolio #AI

## Keep it clean

- The posts above make **no performance claims** and quote no internal numbers. Keep it that way unless Spyne has OK'd
  specific figures.
- Tag only people or companies you have a reason to tag. Spyne is named as your employer, as on your profile.
